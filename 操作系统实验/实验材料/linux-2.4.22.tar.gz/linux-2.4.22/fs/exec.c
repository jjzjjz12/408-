/*
 *  linux/fs/exec.c
 *
 *  Copyright (C) 1991, 1992  Linus Torvalds
 */

/*
 * #!-checking implemented by tytso.
 */
/*
 * Demand-loading implemented 01.12.91 - no need to read anything but
 * the header into memory. The inode of the executable is put into
 * "current->executable", and page faults do the actual loading. Clean.
 *
 * Once more I can proudly say that linux stood up to being changed: it
 * was less than 2 hours work to get demand-loading completely implemented.
 *
 * Demand loading changed July 1993 by Eric Youngdale.   Use mmap instead,
 * current->executable is only used by the procfs.  This allows a dispatch
 * table to check for several different types  of binary formats.  We keep
 * trying until we recognize the file or we run out of supported binary
 * formats. 
 */

#include <linux/config.h>
#include <linux/slab.h>
#include <linux/file.h>
#include <linux/mman.h>
#include <linux/a.out.h>
#include <linux/stat.h>
#include <linux/fcntl.h>
#include <linux/smp_lock.h>
#include <linux/init.h>
#include <linux/pagemap.h>
#include <linux/highmem.h>
#include <linux/spinlock.h>
#include <linux/personality.h>
#include <linux/swap.h>
#include <linux/utsname.h>
#define __NO_VERSION__
#include <linux/module.h>

#include <asm/uaccess.h>
#include <asm/pgalloc.h>
#include <asm/mmu_context.h>

#ifdef CONFIG_KMOD
#include <linux/kmod.h>
#endif

int core_uses_pid;
char core_pattern[65] = "core";
/* The maximal length of core_pattern is also specified in sysctl.c */ 

static struct linux_binfmt *formats;
static rwlock_t binfmt_lock = RW_LOCK_UNLOCKED;

int register_binfmt(struct linux_binfmt * fmt)
{
	struct linux_binfmt ** tmp = &formats;

	if (!fmt)
		return -EINVAL;
	if (fmt->next)
		return -EBUSY;
	write_lock(&binfmt_lock);
	while (*tmp) {
		if (fmt == *tmp) {
			write_unlock(&binfmt_lock);
			return -EBUSY;
		}
		tmp = &(*tmp)->next;
	}
	fmt->next = formats;
	formats = fmt;
	write_unlock(&binfmt_lock);
	return 0;	
}

int unregister_binfmt(struct linux_binfmt * fmt)
{
	struct linux_binfmt ** tmp = &formats;

	write_lock(&binfmt_lock);
	while (*tmp) {
		if (fmt == *tmp) {
			*tmp = fmt->next;
			write_unlock(&binfmt_lock);
			return 0;
		}
		tmp = &(*tmp)->next;
	}
	write_unlock(&binfmt_lock);
	return -EINVAL;
}

static inline void put_binfmt(struct linux_binfmt * fmt)
{
	if (fmt->module)
		__MOD_DEC_USE_COUNT(fmt->module);
}

/*
 * Note that a shared library must be both readable and executable due to
 * security reasons.
 *
 * Also note that we take the address to load from from the file itself.
 */
asmlinkage long sys_uselib(const char * library)
{
	struct file * file;
	struct nameidata nd;
	int error;

	error = user_path_walk(library, &nd);
	if (error)
		goto out;

	error = -EINVAL;
	if (!S_ISREG(nd.dentry->d_inode->i_mode))
		goto exit;

	error = permission(nd.dentry->d_inode, MAY_READ | MAY_EXEC);
	if (error)
		goto exit;

	file = dentry_open(nd.dentry, nd.mnt, O_RDONLY);
	error = PTR_ERR(file);
	if (IS_ERR(file))
		goto out;

	error = -ENOEXEC;
	if(file->f_op && file->f_op->read) {
		struct linux_binfmt * fmt;

		read_lock(&binfmt_lock);
		for (fmt = formats ; fmt ; fmt = fmt->next) {
			if (!fmt->load_shlib)
				continue;
			if (!try_inc_mod_count(fmt->module))
				continue;
			read_unlock(&binfmt_lock);
			error = fmt->load_shlib(file);
			read_lock(&binfmt_lock);
			put_binfmt(fmt);
			if (error != -ENOEXEC)
				break;
		}
		read_unlock(&binfmt_lock);
	}
	fput(file);
out:
  	return error;
exit:
	path_release(&nd);
	goto out;
}

/*
 * count() counts the number of arguments/envelopes
 */
static int count(char ** argv, int max)
{
	int i = 0;

	if (argv != NULL) {
		for (;;) {
			char * p;

			if (get_user(p, argv))
				return -EFAULT;
			if (!p)
				break;
			argv++;
			if(++i > max)
				return -E2BIG;
		}
	}
	return i;
}

/*
 * 'copy_strings()' copies argument/envelope strings from user
 * memory to free pages in kernel mem. These are in a format ready
 * to be put directly into the top of new user memory.
 */
int copy_strings(int argc,char ** argv, struct linux_binprm *bprm) 
{
	struct page *kmapped_page = NULL;
	char *kaddr = NULL;
	int ret;

	while (argc-- > 0) {
		char *str;
		int len;
		unsigned long pos;

		if (get_user(str, argv+argc) ||
				!(len = strnlen_user(str, bprm->p))) {
			ret = -EFAULT;
			goto out;
		}

		if (bprm->p < len)  {
			ret = -E2BIG;
			goto out;
		}

		bprm->p -= len;
		/* XXX: add architecture specific overflow check here. */ 
		pos = bprm->p;

		while (len > 0) {
			int i, new, err;
			int offset, bytes_to_copy;
			struct page *page;

			offset = pos % PAGE_SIZE;
			i = pos/PAGE_SIZE;
			page = bprm->page[i];
			new = 0;
			if (!page) {
				page = alloc_page(GFP_HIGHUSER);
				bprm->page[i] = page;
				if (!page) {
					ret = -ENOMEM;
					goto out;
				}
				new = 1;
			}

			if (page != kmapped_page) {
				if (kmapped_page)
					kunmap(kmapped_page);
				kmapped_page = page;
				kaddr = kmap(kmapped_page);
			}
			if (new && offset)
				memset(kaddr, 0, offset);
			bytes_to_copy = PAGE_SIZE - offset;
			if (bytes_to_copy > len) {
				bytes_to_copy = len;
				if (new)
					memset(kaddr+offset+len, 0,
						PAGE_SIZE-offset-len);
			}
			err = copy_from_user(kaddr+offset, str, bytes_to_copy);
			if (err) {
				ret = -EFAULT;
				goto out;
			}

			pos += bytes_to_copy;
			str += bytes_to_copy;
			len -= bytes_to_copy;
		}
	}
	ret = 0;
out:
	if (kmapped_page)
		kunmap(kmapped_page);
	return ret;
}

/*
 * Like copy_strings, but get argv and its values from kernel memory.
 */
int copy_strings_kernel(int argc,char ** argv, struct linux_binprm *bprm)
{
	int r;
	mm_segment_t oldfs = get_fs();
	set_fs(KERNEL_DS); 
	r = copy_strings(argc, argv, bprm);
	set_fs(oldfs);
	return r; 
}

/*
 * This routine is used to map in a page into an address space: needed by
 * execve() for the initial stack and environment pages.
 *
 * tsk->mmap_sem is held for writing.
 */
void put_dirty_page(struct task_struct * tsk, struct page *page, unsigned long address)
{
	pgd_t * pgd;
	pmd_t * pmd;
	pte_t * pte;
	struct vm_area_struct *vma; 
	pgprot_t prot = PAGE_COPY; 

	if (page_count(page) != 1)
		printk(KERN_ERR "mem_map disagrees with %p at %08lx\n", page, address);
	pgd = pgd_offset(tsk->mm, address);

	spin_lock(&tsk->mm->page_table_lock);
	pmd = pmd_alloc(tsk->mm, pgd, address);
	if (!pmd)
		goto out;
	pte = pte_alloc(tsk->mm, pmd, address);
	if (!pte)
		goto out;
	if (!pte_none(*pte))
		goto out;
	lru_cache_add(page);
	flush_dcache_page(page);
	flush_page_to_ram(page);
	/* lookup is cheap because there is only a single entry in the list */
	vma = find_vma(tsk->mm, address); 
	if (vma) 
		prot = vma->vm_page_prot;
	set_pte(pte, pte_mkdirty(pte_mkwrite(mk_pte(page, prot))));
	tsk->mm->rss++;
	spin_unlock(&tsk->mm->page_table_lock);

	/* no need for flush_tlb */
	return;
out:
	spin_unlock(&tsk->mm->page_table_lock);
	__free_page(page);
	force_sig(SIGKILL, tsk);
	return;
}

int setup_arg_pages(struct linux_binprm *bprm)
{
	unsigned long stack_base;
	struct vm_area_struct *mpnt;
	int i;

	stack_base = STACK_TOP - MAX_ARG_PAGES*PAGE_SIZE;

	bprm->p += stack_base;
	if (bprm->loader)
		bprm->loader += stack_base;
	bprm->exec += stack_base;

	mpnt = kmem_cache_alloc(vm_area_cachep, SLAB_KERNEL);
	if (!mpnt) 
		return -ENOMEM; 
	
	down_write(&current->mm->mmap_sem);
	{
		mpnt->vm_mm = current->mm;
		mpnt->vm_start = PAGE_MASK & (unsigned long) bprm->p;
		mpnt->vm_end = STACK_TOP;
		mpnt->vm_flags = VM_STACK_FLAGS;
		mpnt->vm_page_prot = protection_map[VM_STACK_FLAGS & 0x7];
		mpnt->vm_ops = NULL;
		mpnt->vm_pgoff = 0;
		mpnt->vm_file = NULL;
		mpnt->vm_private_data = (void *) 0;
		insert_vm_struct(current->mm, mpnt);
		current->mm->total_vm = (mpnt->vm_end - mpnt->vm_start) >> PAGE_SHIFT;
	} 

	for (i = 0 ; i < MAX_ARG_PAGES ; i++) {
		struct page *page = bprm->page[i];
		if (page) {
			bprm->page[i] = NULL;
			put_dirty_page(current,page,stack_base);
		}
		stack_base += PAGE_SIZE;
	}
	up_write(&current->mm->mmap_sem);
	
	return 0;
}

struct file *open_exec(const char *name)
{
	struct nameidata nd;
	struct inode *inode;
	struct file *file;
	int err = 0;

	err = path_lookup(name, LOOKUP_FOLLOW|LOOKUP_POSITIVE, &nd);
	file = ERR_PTR(err);
	if (!err) {
		inode = nd.dentry->d_inode;
		file = ERR_PTR(-EACCES);
		if (!(nd.mnt->mnt_flags & MNT_NOEXEC) &&
		    S_ISREG(inode->i_mode)) {
			int err = permission(inode, MAY_EXEC);
			if (!err && !(inode->i_mode & 0111))
				err = -EACCES;
			file = ERR_PTR(err);
			if (!err) {
				file = dentry_open(nd.dentry, nd.mnt, O_RDONLY);
				if (!IS_ERR(file)) {
					err = deny_write_access(file);
					if (err) {
						fput(file);
						file = ERR_PTR(err);
					}
				}
out:
				return file;
			}
		}
		path_release(&nd);
	}
	goto out;
}

int kernel_read(struct file *file, unsigned long offset,
	char * addr, unsigned long count)
{
	mm_segment_t old_fs;
	loff_t pos = offset;
	int result = -ENOSYS;

	if (!file->f_op->read)
		goto fail;
	old_fs = get_fs();
	set_fs(get_ds());
	result = file->f_op->read(file, addr, count, &pos);
	set_fs(old_fs);
fail:
	return result;
}

static int exec_mmap(void)
{
	struct mm_struct * mm, * old_mm;

	old_mm = current->mm;
	if (old_mm && atomic_read(&old_mm->mm_users) == 1) {
		mm_release();
		exit_mmap(old_mm);
		return 0;
	}

	mm = mm_alloc();
	if (mm) {
		struct mm_struct *active_mm;

		if (init_new_context(current, mm)) {
			mmdrop(mm);
			return -ENOMEM;
		}

		/* Add it to the list of mm's */
		spin_lock(&mmlist_lock);
		list_add(&mm->mmlist, &init_mm.mmlist);
		mmlist_nr++;
		spin_unlock(&mmlist_lock);

		task_lock(current);
		active_mm = current->active_mm;
		current->mm = mm;
		current->active_mm = mm;
		task_unlock(current);
		activate_mm(active_mm, mm);
		mm_release();
		if (old_mm) {
			if (active_mm != old_mm) BUG();
			mmput(old_mm);
			return 0;
		}
		mmdrop(active_mm);
		return 0;
	}
	return -ENOMEM;
}

/*
 * This function makes sure the current process has its own signal table,
 * so that flush_signal_handlers can later reset the handlers without
 * disturbing other processes.  (Other processes might share the signal
 * table via the CLONE_SIGNAL option to clone().)
 */
 
static inline int make_private_signals(void)
{
	struct signal_struct * newsig;

	if (atomic_read(&current->sig->count) <= 1)
		return 0;
	newsig = kmem_cache_alloc(sigact_cachep, GFP_KERNEL);
	if (newsig == NULL)
		return -ENOMEM;
	spin_lock_init(&newsig->siglock);
	atomic_set(&newsig->count, 1);
	memcpy(newsig->action, current->sig->action, sizeof(newsig->action));
	spin_lock_irq(&current->sigmask_lock);
	current->sig = newsig;
	spin_unlock_irq(&current->sigmask_lock);
	return 0;
}
	
/*
 * If make_private_signals() made a copy of the signal table, decrement the
 * refcount of the original table, and free it if necessary.
 * We don't do that in make_private_signals() so that we can back off
 * in flush_old_exec() if an error occurs after calling make_private_signals().
 */

static inline void release_old_signals(struct signal_struct * oldsig)
{
	if (current->sig == oldsig)
		return;
	if (atomic_dec_and_test(&oldsig->count))
		kmem_cache_free(sigact_cachep, oldsig);
}

/*
 * These functions flushes out all traces of the currently running executable
 * so that a new one can be started
 */

static inline void flush_old_files(struct files_struct * files)
{
	long j = -1;

	write_lock(&files->file_lock);
	for (;;) {
		unsigned long set, i;

		j++;
		i = j * __NFDBITS;
		if (i >= files->max_fds || i >= files->max_fdset)
			break;
		set = files->close_on_exec->fds_bits[j];
		if (!set)
			continue;
		files->close_on_exec->fds_bits[j] = 0;
		write_unlock(&files->file_lock);
		for ( ; set ; i++,set >>= 1) {
			if (set & 1) {
				sys_close(i);
			}
		}
		write_lock(&files->file_lock);

	}
	write_unlock(&files->file_lock);
}

/*
 * An execve() will automatically "de-thread" the process.
 * Note: we don't have to hold the tasklist_lock to test
 * whether we migth need to do this. If we're not part of
 * a thread group, there is no way we can become one
 * dynamically. And if we are, we only need to protect the
 * unlink - even if we race with the last other thread exit,
 * at worst the list_del_init() might end up being a no-op.
 */
static inline void de_thread(struct task_struct *tsk)
{
	if (!list_empty(&tsk->thread_group)) {
		write_lock_irq(&tasklist_lock);
		list_del_init(&tsk->thread_group);
		write_unlock_irq(&tasklist_lock);
	}

	/* Minor oddity: this might stay the same. */
	tsk->tgid = tsk->pid;
}

int flush_old_exec(struct linux_binprm * bprm)
{
	char * name;
	int i, ch, retval;
	struct signal_struct * oldsig;
	struct files_struct * files;

	/*
	 * Make sure we have a private signal table
	 */
	oldsig = current->sig;
	retval = make_private_signals();
	if (retval) goto flush_failed;

	/*
	 * Make sure we have private file handles. Ask the
	 * fork helper to do the work for us and the exit
	 * helper to do the cleanup of the old one.
	 */
	 
	files = current->files;		/* refcounted so safe to hold */
	retval = unshare_files();
	if(retval)
		goto flush_failed;
	
	/* 
	 * Release all of the old mmap stuff
	 */
	retval = exec_mmap();
	if (retval) goto mmap_failed;

	/* This is the point of no return */
	steal_locks(files);
	put_files_struct(files);
	release_old_signals(oldsig);

	current->sas_ss_sp = current->sas_ss_size = 0;

	if (current->euid == current->uid && current->egid == current->gid) {
		current->mm->dumpable = 1;
		current->task_dumpable = 1;
	}
	name = bprm->filename;
	for (i=0; (ch = *(name++)) != '\0';) {
		if (ch == '/')
			i = 0;
		else
			if (i < 15)
				current->comm[i++] = ch;
	}
	current->comm[i] = '\0';

	flush_thread();

	de_thread(current);

	if (bprm->e_uid != current->euid || bprm->e_gid != current->egid || 
	    permission(bprm->file->f_dentry->d_inode,MAY_READ))
		current->mm->dumpable = 0;

	/* An exec changes our domain. We are no longer part of the thread
	   group */
	   
	current->self_exec_id++;
			
	flush_signal_handlers(current);
	flush_old_files(current->files);

	return 0;

mmap_failed:
	put_files_struct(current->files);
	current->files = files;
flush_failed:
	spin_lock_irq(&current->sigmask_lock);
	if (current->sig != oldsig) {
		kmem_cache_free(sigact_cachep, current->sig);
		current->sig = oldsig;
	}
	spin_unlock_irq(&current->sigmask_lock);
	return retval;
}

/*
 * We mustn't allow tracing of suid binaries, unless
 * the tracer has the capability to trace anything..
 */
static inline int must_not_trace_exec(struct task_struct * p)
{
	return (p->ptrace & PT_PTRACED) && !(p->ptrace & PT_PTRACE_CAP);
}

/* 
 * Fill the binprm structure from the inode. 
 * Check permissions, then read the first 128 (BINPRM_BT* Fill read theo_copy copy_strpre nid* bprm)(inux_binprm *bprm)
{
	int r;
	mm_smruct file *finode;
	 nd.dentrle->f_dentry->d_inode,MAY_REA = km.dentr_mode & 0111); Make surrmissile
 * eions,e egfile-ace ve_mm)e_unloc->files);

 * Not/C_OVERRIDE,ile
 vf{
			d the f letsic in in  security/
	oughec_mmapflags err = -EACCESs our thrto bexit,[j]e_ns,e egfite_ 1) {list_pin_lock_RR_PTR(e current->->f_op->rea-ENOMEM;
	spin_lock_RR_PTR(ack_base;uid | bprm->e_gid !=tack_base;_gd | bprm->e_gidgidd != cgs rent->->f_op->vf{NT_NOEXEC) &&
		    S_ISUIDirq(&ta/for t- !=?{list_ mm_srr = -ode)UIDi= NULL;
		;uid | b11); Makeuidd !=a/for t-g!=?{list_ssil	_signa1) gd | re1) {ts vtherent->s,e egfite_ t 128e sail	_si it wdyndinod.

    at ftin kval;f (!p# Note1) gd il	_sin  securit.il	_sist_ mm__srr = -(ode)GI (erodeXGRP)ease((ode)GI (erodeXGRP)e= NULL;
		;ugd | b11); Makegidd ty: thisWld the taskliVFS * forma

   e anythinope y) {liste a_BNODE rent->e a_in* aicurit = fi a_BNODE rent->e a_			d td * = fi a_BNODE rent->e a_effen 0;
r flush_ Tnks and t in* aicuudlyby aoot-read the fihelpeess
-aoot
         h_ n  securitbases onntedst_ything.m	if (ast oimmap st/
	 e
         h_ e anything.setsiack and linux
         h
         h_ gnact this acc	ifud | re0protect th oimmack per* aicurit
         h_  the 		d td *.setsiis put into
 * "culinux
         h/->read)
 th*
 *e(SECURES_IROOT)')
			i = LL;
		;uid | PAGE	retrent->egid ==plus_brecfi a_il:
	ull rent->e a_in* aicurit = fcfi a_il:
	ull rent->e a_			d td * = fight != heL;
		;uid | PAGM; 
	fi a_il:
	ull rent->e a_effen 0;
r f();
	i+len, rent->buf,0,ad theo_copy cop}

/*
 * W file *file,rent->->f_,0,rent->buf,ad theo_copy cop}
tion makes sure the cura page intoproducmack prtedIDihelpee anythinope
#inc Check pfiles = helper to->f_'see anythinopesem is h of  be ulapage iack evolv993 b anythinope is:(C) 199111111pI'e, MI Tech***) pP'e, (fP= -X)(er(fI= -pI) 199111111pE'e, MP'e& fE          [NB. fE  re0supp~0](C) 199I=In* aicurit, P=P		d td *, E=Effen 0;
 // p=we don', f=->f_)' co  key foust ret- occurecessaXo returnglob	if'e a_ben,'sem is /d_exit(ntedegf, nudprm *bprm)
{
	unsigned long kmapp file *e a_tprte_			d td *,he ext)cnidfiledont->sig changesrte_			d td *| bp a_int thect rent->e a_			d td *, e a_ben,
		if ext)c| bp a_int thect rent->e a_in* aicurit,[i++] = ch;
	}
 a_in* aicurit = frte_			d td *| bp a_ntensie(rte_			d td *,he ext)cid != current->euid || bprm->e_gi != current->egid || 
	    permssion(prm->f!
 a_issuben,(rte_			d td *,h = ch;
	}
 a_			d td * s_br                ble = 0;

	/* An exec changandl	>sigmar ** a
			if (ac(struct task_structld_filesde->i_mcurnt->sig->count) <= 1)
fseturn 0;
> 1de->i_mcurnt->sig->count) <= 1)
fc->fds_rn 0;
> 1de->i_mcurnt->sig->count) <= 1)
		return 0;
> 1) {
				s(!b anyle(* NoSETUIDirq(&ta	ck_base;uid | bprm->e_gi !=tac NULL;
		;ugd | b	    permssi&& offset)
	(!b anyle(* NoSETPll trq(&ta	crte_			d td *| bp a_int thect rte_			d td *,PTR(err	 = ch;
	}
 a_			d td * _lock(&files-dont->sig ch->fileflush_For enviprotewantbut
 *taa = finb anythinope en,
         h_a = fin	mmli
	ree inodeormausroteskip= finusue CL        h_e anything.r    _mmapflag = ch;
	}pd || 
1>dumpable = 1;

 a_			d td *nlock__			d td *;mpable = 1;

 a_effen 0;
 = 
	fi a_int thect rte_			d td *, rent->e a_effen 0;
r f();	CL        ourUD: Aude_ dyndinod.
flable = 1;

 a_effen 0;
  re1) { /d_        ble = 0;
sid | bprm->e_gid !=		/* refcountsid | bk_base;uid ;_        ble = 0;
sgd | bprm->e_gidgid		/* refcountsgd | bk_base;ugidd != cgdont->sig)et, i>sigmar ** a
			* refcounil w_b anythinope = *open_
ignals(ndenlinuxzerorm *bprm)
{
	int r;
	mm_smruct fcurrent-> = strset, i;

		j++;
		es_to_copyi, ch,  byte;
e;

			offset = pos % PAE_SIZE;
	ase;
	if= pos/PAGE_SIZEode->pasintr_mo
			int ase;
	i++, * 0,
						PAGE+)) {
				sysE_SIZE;!p_write(&cu	read_unlock(&binfmE_SIZE;
	
				pe);
	reSIGKILLpasint:age[i];
			new = 0;
		new = 0e = bprm->if (!ped_page);
			(new && o}
	pe);
	reSIGKILLNULL;
		ar *st of resour the ycle*/
		spin_loce keep
 * tryi * distu,e the f
 */ or we rusnty of
IGKre nid* be(fd->ke keep;
	flushrm *bprm)
{
	int r;
	mm_sm,

			offtg->&
	*->&
ruct fileNLY)e must=0;fmt ** tmp = &formats;
&binf
#inclu__alpha__lush_
	flus /sorm/se;
	b.tsk->p{prm->ft ** tmomainsin'\0'(t ** tmomains>vm_end bufr_moerms es = ck_base;
	bp = hhunth.f_ dep'| PAGx183inode-(hhunth.f_) &&
		 0x3000)| PAGx3000)moermsct *active_ct nameidata n, i;

		j++;
		se;
	br_mo
uid b);
					if (errent->->f_ i++,sturnrent->->f_ i++,rent->->f_rty_page(PAGE_CACH	se;
	bset;
			if (*+) {
		struct-ion));
t_vm_str_mo
->f_rtyar *name)
"/sorm/se;
	b"	return 
	if ( (IS_ERR(file))

		goto out;

	error 
/*
 * We mustn'!=a/foRei+lnvel_unloc-apply fo cura pTASO. _sist_rent->s>kea)c| bhhunah.*/
	vm<AGx173253 0anges,rent->->f_rtyidata n, ck_base;
	bp=	se;
	br_turn 
	if (prm)(inux_binprfs);
	remmap_failed<0ror 
/*
 * We mustn'=a/foed a co>filbe(fd->ke keep;
	flush/ orur use atcan ree->cnts viledoesp# Nomcifie>self_ex :
	iftest_bit/fo
int copue;
		se;
	bsfixt->self/e canold the ttn kern fileed bpuewe beese are in * exetsk->pil:
	reage[tring*(name+tn )) !tn <2 !tn e *page lock);
		for (fmt = formats ; fmt ; fmt = fmt->next) {
			if (!fmt->load_shliile(*fn)rm *bprm)
{
	int r;
	me, unsignetg->&
	*)(file);
			ree keep			file = fn	if (!try_inc_mod_count(fmt->module))
				continue;
			read_unlock(&binfmt_lock);
			error = fmt->load_rn 
	if (fntry->signe_actiemmap_failedfsplus_brec
			if (error != -ENOE
uid b);
					if (errent->->f_ i++,	e current->->f_r+offsesturnrent->->f_ i++,+,rent->->f_rty_page(err	 = ch;
	}dinname)(page != 
/*
 * We mustn'=affset)lock);
			put_binfmt(fmt);
			if (error != -ENOEXEC)failedfreak;
		}
		read_unlock(&b	 es = ck_ba->f_ LT;
				glock);
			error = fmt->load_
/*
 * We mustn'=affsetinfmt_lock);
	}
	fput(file);
outEXEC)failedfreak;
		}
		] = NULnlock(
#include <linux/kmeti)
		{ION__
#inem_manyle(str(((st=='\t'trnl ((st=='\n'trnl (0x20<=(str = (st<=0x7			readi, chnue {
	[20]k(&b	 es em_manyle(m_end buf[0](inode-rm->fim_manyle(m_end buf[1](inode-rm->fim_manyle(m_end buf[2](inode-rm->fim_manyle(m_end buf[3])	read_unlock  ouk;
		}
	_sist_	sim_maf(nue {
	, "fput(f-%04x", *  i;

		j+ed rs;
)
	f_end buf[2](>load_rnquSPLUnue;
	(nue {
	f (test_bit(HF;
}

/*
 * e mustn't aour the
		}maticallys,e egfsstartedrite toings_kernedonmaticali, ch, 0; (ch =, ct linux_binprct linuxenvpe, unsignetg->&
	* ->&
ruct m *bprm)
{
	int r;
	f_enle;
	int err = 0;

	err = pe mustn'=e = STACK->f_rtyar *name)
0; (ch =ap_faile
	if ( (IS_ERR(file))
		goto out;

	error /*
 * We mustn'!=f_en.pset;
			if (*+) {
		struct-ion));
t_vm_str_	i+len, rent.sk->mm0,E_SIZE;

	bprm-ion));
rent.sk->[0]()t(pagrent.->f_rtyidata nrent.->f_ame;
	f0; (ch = *(rent.s>kea)c| b0 *(rent.se;
	bp=	0 *(rent.ame)(pa0))
		go
rent.ar *gc, a				fs(oldfs);.ps/ ion));
t_vm_st)) t;
		whiluid b);
					if (er->f_ i++,sturn->f_ i++,/*
 * Wrent.ar * f();
			go
rent.env*gc, a				envpe,fs);.ps/ ion));
t_vm_st)) t;
		whiluid b);
					if (er->f_ i++,sturn->f_ i++,/*
 * Wrent.env* f();
	rn 
	if (prm)(inux_binpr&fs);
	reXEC)failedf<AGM; 
	ernel_rea ;
	rn 
	if (l(int argc,char ** a1, &rent.->f_ame;, &rent
	reXEC)failedf<AGM; 
	ernel_rea ;
	rent.ame)(pafs);.p;
	rn 
	if (l(int argc,c
rent.env*,xenvpe,&fs);
	reXEC)failedf<AGM; 
	ernel_rea ;
	rn 
	if (l(int argc,c
rent.ar *t_fs(old&fs);
	reXEC)failedf<AGM; 
	ernel_rea ;
	rn 
	if (e(fd->ke keep;
	flushr&fs);,gne_actimap_failedfsplus'=a/fomatica sutter
plist_pin_loce mustn'!le;
		/forie not a wt ofwro (!ppin_locck permiscessary.
 loc-atrings >mmap_listuid b);
					if (errent.(file))
		gorent.(file++,sturnrent.(file)) MAX_ARG_PAGES ; i++) {
		struct page *page = bprm->page[ i];
			new .e) {
			bprm->page[ioad_
	force_sig(SIGKILL,}
}

/*
 * e mustn't at_vm_il:
x_binfmt * fmt)
{
	if (fmt->addr+nfmt ** tmp = &formats;
file	/* refcounormatsULL)
		retr = retDEC_USE_COUNT(fmt-INodule);
}

/retDEC_USE_C			* refcounormats;lock_tomic_readmset(ldDEC_USE_COUNT(fmt->module);
}

/(ldDEC_USE_Cn't aON__
#inCORENAM lonX	if (b64binprt = fm_so same;
 "de-inchect() miecified )(ime;ttu,eessale;the a
h, retvpace: so same;oves anyble aaskli* exeiack to bexitons, ORENAM lonX	if (b_strpr Linu
 */_striack and zeroGener ketorty_page(strt = fm_so same;li, ch,so same;ov{
	struct naecified,++;
		i

	r	int i
	struct naeci_ptme, LOOfiedULL;
	intle;_ptme, so same;ULL;
	inti
	strle;_	mpnt-so same;
+, ORENAM lonX	if (err = pe= 0;
	e pikm.dpecified changes ouRepee stspgd_t *sile handl say ecified ntoproter
perfo say le;thelf_ex* exeilistf (fmt =eci_ptm')
			i = aeci_ptmech =%') {
				sysEe;_ptme,=rle;_	mp)}

			pos += bytestle;_ptm++\0';eci_ptmnal_hacnt >= bnod	switany(*++eci_ptm')
				c mma0:}

			pos += bytes ouDouxec percrop(mle;the 
 */percrop_sist_	c mma=%':++,	e curEe;_ptme,=rle;_	mp)}

					new = 1;
			tle;_ptm++\0'=%';read_unlock(&b	 oupd |sist_	c mma=p':++,	epikm.dpecified chge != 
/)(pasnim_maf(le;_ptm,rle;_	mpn- le;_ptm,}

			_CACH	"%d",h = ch;
	}pik i++,	e cur/)(>rle;_	mpn- le;_ptm)}

					new = 1;
			Ee;_ptme+=pe= 0;ad_unlock(&b	 ouud |sist_	c mma=u':++,	e/)(pasnim_maf(le;_ptm,rle;_	mpn- le;_ptm,}

			_CACH	"%d",h = ch;
	}uik i++,	e cur/)(>rle;_	mpn- le;_ptm)}

					new = 1;
			Ee;_ptme+=pe= 0;ad_unlock(&b	 ougd |sist_	c mma=g':++,	e/)(pasnim_maf(le;_ptm,rle;_	mpn- le;_ptm,}

			_CACH	"%d",h = ch;
	}gik i++,	e cur/)(>rle;_	mpn- le;_ptm)}

					new = 1;
			Ee;_ptme+=pe= 0;ad_unlock(&b	 ou	oldsig be sy a sper toso s An |sist_	c mma=s':++,	e/)(pasnim_maf(le;_ptm,rle;_	mpn- le;_ptm,}

			_CACH	"%ld",hi

	r	i++,	e cur/)(>rle;_	mpn- le;_ptm)}

					new = 1;
			Ee;_ptme+=pe= 0;ad_unlock(&b	 ouUNIX times also s An |sist_	c mma=t':);
			}
* p)
{
imeledft				re-donget
imeofdaup))v);++,	e/)(pasnim_maf(le;_ptm,rle;_	mpn- le;_ptm,}

			_CACH	"%ld",htv.tv_sec	i++,	e cur/)(>rle;_	mpn- le;_ptm)}

					new = 1;
			Ee;_ptme+=pe= 0;ad_unlock(&b	}(&b	 ouhostame;
sist_	c mma=h':++,	et->mm->counuts;
}

str,	e/)(pasnim_maf(le;_ptm,rle;_	mpn- le;_ptm,}

			_CACH	"%s",hi# Not_ __NO_VErmisch =ap_
			upm->counuts;
}

str,	e cur/)(>rle;_	mpn- le;_ptm)}

					new = 1;
			Ee;_ptme+=pe= 0;ad_unlock(&b	 ouinto
 * "cusist_	c mma=e':++,	e/)(pasnim_maf(le;_ptm,rle;_	mpn- le;_ptm,}

			_CACH	"%s",h = ch;
	}flus
str,	e cur/)(>rle;_	mpn- le;_ptm)}

					new = 1;
			Ee;_ptme+=pe= 0;ad_unlock(&b	N__l lo:0;ad_unlock(&b	}(&b	++eci_ptm
out:
	if  ouBackwresontedst_ything.r thrr core_patter:ec_m
	_signaso specified doesp# Nod.h>
#enaage,(ano returnN__l lo)
	_sielpee core_patter  re1) rst 128.%ter   but WIrn rnde int
	_sir to->f_ame;
sist))
		gikm.dpecifiedr             = (s core_patter curnt->sig->count) <= 1)
) {
		mm_relea| 
1>*page l)(pasnim_maf(le;_ptm,rle;_	mpn- le;_ptm,}

	_CACH	".%d",h = ch;
	}pik i++, cur/)(>rle;_	mpn- le;_ptm)}

			new = 1;
	Ee;_ptme+=pe= 0;}r      le;
		tle;_ptme, btree_movedo_so s An (+;
		i

	re, unsignetg->&
	* ->&
ruct m *bprm)
{
	int _lock(ormatsULL65] = "co {
	[ ORENAM lonX	if (b+ 1];le;
	struct nameidata nd;
	int.dentrle->f_derr = pe must changes>sigmar ** a
			ormats;lo* refcounormatsULL)
		!ormats;cur!ormats	}flcor An d_fs = get_fs();ead)
 t	name = btld_filesd_fs = get_fs();ble = 0;

	/* An exec changaflag = ch;
	}rlim[RLIMIT_ ORE].rlim_ =  i+ormats	}r k_so s An d_fs = get_fs()
 	t = fm_so same;lio same;ov{
 specified,hi

	r	i++->f_rtyidapd.mnt,io same;ovO_CREAT | 2 | O_NOTIVE, , 0600e))
		goto out;

	error = -ENt_fs();e	tree = node,MAY_REA = km.dentr_ext(cur); Make race >ewsig = -EN_bits[t_fs(  oum loi30, urce f-make_priAn |sistxt(cock)haee S( node,MAY_REA )sig = -EN_bits[t_fs(
dentry->d_inodegoto exit;

	error = pe_bits[t_fs(
read)
		goto fairror = pe_bits[t_fs(
read)
		goto fai->;
			rror = pe_bits[t_fs(
read)do_;
	n fou( node,MAY_REA ,AGM;!plus'=a= -EN_bits[t_fs(
dee must chormats	}flcor An (i

	re,->&
, (file)) _bits[t_fs:++->fp}
		wri &pos)OMEM;sult;
}

 i>sigmar ** a
		